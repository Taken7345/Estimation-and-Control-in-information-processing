import numpy as np

# 1. Define your data (replace these with your actual numbers)
# Example: 3x2 matrix A, 2x1 vector x, 3x1 vector y
A = np.array([[1, 2], 
              [3, 4], 
              [5, 6]])

x = np.array([0.5, 1.5]) 

y = np.array([3.0, 8.0, 11.0])

# 2. Compute predicted values (Ax)
# Note: The '@' symbol is used for matrix multiplication in numpy
predicted_values = A @ x
print("Predicted values (Ax):")
print(predicted_values)

# 3. Compute the residual (r = y - Ax)
residual = y - predicted_values
print("\nResidual (r):")
print(residual)

# 4. Compute the squared error
# Squaring the residual array and summing the values
squared_error = np.sum(residual**2)
print("\nSquared Error:")
print(squared_error)