import numpy as np

x = np.array([1, 2, 3])
y = np.array([40, 42, 45])

A = np.vstack([x, np.ones(len(x))]).T

print("Matrix A:")
print(A)
print("\nVector y:")
print(y)

solution, residuals, rank, s = np.linalg.lstsq(A, y, rcond=None)

a = solution[0]
b = solution[1]

print("\n--- Results ---")
print(f"Slope (a): {a:.4f}")
print(f"Intercept (b): {b:.4f}")
print(f"Best fit line: y = {a:.4f}x + {b:.4f}")