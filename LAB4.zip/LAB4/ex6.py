import numpy as np

# 1. Define the error values
errors = np.array([-1, 2, -2])

print(f"Individual Errors: {errors}")

squared_errors = errors**2
total_squared_error = np.sum(squared_errors)

print("\n--- Squared Error Analysis ---")
print(f"Individual Squared Errors: {squared_errors}")
print(f"Total Squared Error: {total_squared_error}")

absolute_errors = np.abs(errors)
total_absolute_error = np.sum(absolute_errors)

print("\n--- Absolute Error Analysis ---")
print(f"Individual Absolute Errors: {absolute_errors}")
print(f"Total Absolute Error: {total_absolute_error}")

print("\n--- Comparison ---")
print(f"Notice how the larger errors (2 and -2) contribute a massive 4 each to the Squared Error, ")
print(f"but only 2 each to the Absolute Error. This demonstrates how Squared Error heavily ")
print(f"penalizes larger deviations in your system.")