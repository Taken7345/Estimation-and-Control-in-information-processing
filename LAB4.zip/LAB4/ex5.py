import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42) 
time_hours = np.linspace(0, 24, 50) 
true_consumption_rate = 1.2         

energy_kwh = true_consumption_rate * time_hours + np.random.normal(0, 1.5, len(time_hours)) + 5.0

slope, intercept = np.polyfit(time_hours, energy_kwh, 1)

print(f"Calculated Consumption Rate (Slope): {slope:.3f} kW")
print(f"Calculated Initial Offset (Intercept): {intercept:.3f} kWh")


plt.figure(figsize=(10, 6))

plt.scatter(time_hours, energy_kwh, label='Smart Home Sensor Data', color='blue', alpha=0.6)

fitted_line = slope * time_hours + intercept
plt.plot(time_hours, fitted_line, 
         label=f'Linear Fit (Rate = {slope:.2f} kW)', 
         color='red', linewidth=2)

plt.title('Smart Home Cumulative Energy vs Time')
plt.xlabel('Time (Hours)')
plt.ylabel('Cumulative Energy (kWh)')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.7)
plt.tight_layout()

plt.show()