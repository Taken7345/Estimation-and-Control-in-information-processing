import numpy as np

sensor1 = [1, 2]
sensor2 = [2, 4]

A = np.column_stack((sensor1, sensor2))

print("Matrix A:")
print(A)

print("\n--- Checking Independence ---")
determinant = np.linalg.det(A)
rank = np.linalg.matrix_rank(A)

print(f"Determinant of A: {determinant:.2f}")
print(f"Rank of A: {rank} (Needs to be 2 for independent columns in a 2x2 matrix)")

if determinant == 0:
    print("Conclusion: The determinant is 0. The columns are linearly dependent.")

print("\n--- Why the System Fails ---")

y = np.array([10, 20])

try:
    
    A_transpose_A = A.T @ A
    inverse_matrix = np.linalg.inv(A_transpose_A)
    
    print("System solved successfully!")

except np.linalg.LinAlgError as error:
    print("SYSTEM CRASH:")
    print(f"LinAlgError: {error}")
    print("Explanation: Because Sensor 2 is just Sensor 1 multiplied by 2, "
          "Matrix A is singular. The computer tries to divide by zero "
          "when calculating the inverse, causing the system to fail.")

print("\n--- Forward Computation with Guessed Weights ---")
x_guess = np.array([1.5, 0.5]) 

predicted_Ax = A @ x_guess
residual_r = y - predicted_Ax
squared_error = np.sum(residual_r**2)

print(f"Guessed weights (x): {x_guess}")
print(f"Predicted values (Ax): {predicted_Ax}")
print(f"Residual (r): {residual_r}")
print(f"Squared Error: {squared_error}")