import numpy as np
from scipy.optimize import least_squares

y = np.array([21, 22, 23, 24])

x_analytical = np.mean(y)

print("--- Approach 1: Mean ---")
print(f"Calibrated temperature (x): {x_analytical}")

def error_function(x, y):
    return y - x  

initial_guess = [20.0]

result = least_squares(error_function, initial_guess, args=(y,))
x_optimized = result.x[0]

print("\n--- Approach 2: Least Squares Optimization ---")
print(f"Calibrated temperature (x): {x_optimized}")