import numpy as np

rng = np.random.default_rng(seed=42)
x_true = 10.0
sigma  = 1.0
n_vals = [1, 5, 10, 50, 100, 500, 1000, 5000]

print(f"True value x = {x_true},  noise σ = {sigma}\n")
print(f"{'N':>6} | {'Sample mean':>12} | {'Bias':>10} | {'Std Error':>10} | {'RMSE':>10}")
print("-" * 58)

for n in n_vals:
    y = x_true + rng.normal(0, sigma, size=n)
    mean_y  = y.mean()
    bias    = mean_y - x_true
    std_err = sigma / np.sqrt(n)          # theoretical standard error
    rmse    = np.sqrt(((y - x_true)**2).mean())
    print(f"{n:>6} | {mean_y:>12.6f} | {bias:>+10.6f} | {std_err:>10.6f} | {rmse:>10.6f}")

print("\n--- Monte Carlo (500 experiments each) ---")
for n in n_vals:
    runs = [x_true + rng.normal(0, sigma, n) for _ in range(500)]
    means = np.array([r.mean() for r in runs])
    mc_bias = (means - x_true).mean()
    mc_std  = means.std()
    print(f"N={n:>5}: avg bias={mc_bias:+.5f},  std of means={mc_std:.5f},  theory σ/√N={sigma/n**0.5:.5f}")