import numpy as np
import matplotlib.pyplot as plt

rng = np.random.default_rng(seed=42)
n = 1000

configs = [(0, 0.5), (0, 1.0), (0, 2.0), (0, 4.0)]
samples = {f"σ={s}": rng.normal(loc=m, scale=s, size=n) for m, s in configs}

fig, axes = plt.subplots(2, 2, figsize=(12, 8))
for ax, (label, data) in zip(axes.flat, samples.items()):
    ax.hist(data, bins=40, density=True, alpha=0.75, color='steelblue')
    x = np.linspace(data.min(), data.max(), 300)
    sigma = float(label.split('=')[1])
    ax.plot(x, np.exp(-x**2 / (2*sigma**2)) / (sigma * np.sqrt(2*np.pi)),
            'r-', lw=2, label='PDF')
    ax.set_title(f'N(0, {sigma}²)  —  var={sigma**2:.2f}')
    ax.legend()
plt.suptitle('Gaussian Noise with Different Variances', fontsize=14)
plt.tight_layout()
plt.show()