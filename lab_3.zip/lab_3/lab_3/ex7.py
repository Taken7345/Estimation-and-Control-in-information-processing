import numpy as np
import matplotlib.pyplot as plt

rng = np.random.default_rng(seed=42)

x_true = 10.0
n = 1000

sigmas = [0.5, 1.0, 2.0]
fig, axes = plt.subplots(1, 3, figsize=(14, 5))

for ax, sigma in zip(axes, sigmas):
    noise = rng.normal(0, sigma, size=n)
    y = x_true + noise

    ax.hist(y, bins=40, density=True, alpha=0.75, color='steelblue', label='Measurements')
    xr = np.linspace(y.min(), y.max(), 300)
    ax.plot(xr, np.exp(-(xr-x_true)**2/(2*sigma**2))/(sigma*np.sqrt(2*np.pi)),
            'r-', lw=2, label='True PDF')
    ax.axvline(x_true, color='green', lw=2, linestyle='--', label=f'True value = {x_true}')
    ax.axvline(y.mean(), color='orange', lw=1.5, linestyle=':', label=f'Sample mean = {y.mean():.3f}')
    ax.set_title(f'σ = {sigma}  (σ² = {sigma**2})')
    ax.legend(fontsize=8)

plt.suptitle('Measurements y = x_true + N(0, σ²),  x_true = 10', fontsize=13)
plt.tight_layout()
plt.show()

noise = rng.normal(0, 1.0, n)
y = x_true + noise
print(f"True value:        {x_true}")
print(f"Sample mean:       {y.mean():.4f}")
print(f"Sample std dev:    {y.std():.4f}")
print(f"Bias (mean - true): {y.mean() - x_true:.4f}")
print(f"RMSE:              {np.sqrt(((y - x_true)**2).mean()):.4f}")