import numpy as np
import matplotlib.pyplot as plt

rng = np.random.default_rng(seed=42)
X = rng.uniform(0, 1, size=1000)   

plt.figure(figsize=(9, 5))
plt.hist(X, bins=20, color='steelblue', edgecolor='white', alpha=0.8, density=True)
plt.axhline(y=1.0, color='tomato', linewidth=2, linestyle='--', label='Theoretical PDF = 1')
plt.title('X ~ Uniform(0, 1) — Histogram')
plt.xlabel('Value')
plt.ylabel('Density')
plt.legend()
plt.tight_layout()
plt.show()

print(f"Mean:     {X.mean():.4f}  (expected 0.5)")
print(f"Std dev:  {X.std():.4f}  (expected {1/12**0.5:.4f})")

#What it looks like: The histogram is roughly flat — all bars sit at approximately the same height, with minor random fluctuations. This is the signature of the uniform distribution.
#Why it's flat: By definition, every value in [0, 1] is equally likely. The probability density function (PDF) is simply f(x) = 1 for 0 ≤ x ≤ 1, and 0 elsewhere — a perfect rectangle. No region of the interval is favored over any other.
#What the small bumps mean: The bars aren't perfectly even, and that's expected. With 1000 samples spread across 20 bins, each bin holds ~50 values on average, and sampling variation causes natural ups and downs. As you increase N (try 10,000 in the widget), the bars flatten out and converge toward the theoretical line — this is the Law of Large Numbers in action.
#Compared to the normal distribution: Unlike the bell curve, the uniform has no peak or tails. It is perfectly symmetric but platykurtic — flatter than a normal, with lighter tails and no concentration around a central value.