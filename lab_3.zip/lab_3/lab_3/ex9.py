import numpy as np
import matplotlib.pyplot as plt

rng = np.random.default_rng(seed=42)
n = 1000

def make_correlated(rho, n, seed):
    rng = np.random.default_rng(seed)
    cov = [[1, rho], [rho, 1]]         
    L   = np.linalg.cholesky(cov)      
    Z   = rng.standard_normal((2, n))
    X, Y = L @ Z                        
    return X, Y

rhos = [0.9, 0.5, 0.0, -0.5, -0.9]
fig, axes = plt.subplots(1, 5, figsize=(18, 4))

for ax, rho in zip(axes, rhos):
    X, Y = make_correlated(rho, n, seed=42)
    cov_xy  = np.cov(X, Y)[0, 1]
    corr_xy = np.corrcoef(X, Y)[0, 1]
    ax.scatter(X, Y, alpha=0.3, s=8, color='steelblue')
    ax.set_title(f'ρ = {rho}  |  Cov = {cov_xy:.3f}')
    ax.set_xlabel('X');  ax.set_ylabel('Y')

plt.suptitle('Correlated Random Variables', fontsize=13)
plt.tight_layout()
plt.show()

X, Y = make_correlated(0.7, n, seed=42)
cov_matrix = np.cov(X, Y)
print("Covariance matrix:\n", cov_matrix)
print(f"\nCov(X,Y)  = {cov_matrix[0,1]:.4f}  (theoretical = 0.70)")
print(f"Corr(X,Y) = {np.corrcoef(X,Y)[0,1]:.4f}  (theoretical = 0.70)")