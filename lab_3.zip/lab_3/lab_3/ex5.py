import numpy as np
import matplotlib.pyplot as plt

rng = np.random.default_rng(seed=42)

G = rng.normal(loc=0, scale=1, size=1000)   

U = rng.uniform(0, 1, size=1000)
U_scaled = (U - 0.5) / (1/12)**0.5          

print("=== Gaussian N(0,1) ===")
print(f"Mean:     {G.mean():.4f}   (expected  0.0)")
print(f"Std dev:  {G.std():.4f}   (expected  1.0)")
print(f"Skewness: {((G - G.mean())**3).mean() / G.std()**3:.4f}  (expected  0.0)")
print(f"Kurtosis: {((G - G.mean())**4).mean() / G.std()**4 - 3:.4f}  (expected  0.0)")

fig, axes = plt.subplots(1, 2, figsize=(12, 5))
axes[0].hist(G, bins=40, color='steelblue', alpha=0.8, density=True, label='N(0,1)')
x = np.linspace(-4, 4, 300)
axes[0].plot(x, np.exp(-x**2/2)/np.sqrt(2*np.pi), 'r-', lw=2, label='Theoretical PDF')
axes[0].set_title('Gaussian N(0,1)')
axes[0].legend()

axes[1].hist(G, bins=40, alpha=0.7, density=True, label='Gaussian N(0,1)', color='steelblue')
axes[1].hist(U_scaled, bins=40, alpha=0.6, density=True, label='Uniform (scaled)', color='seagreen')
axes[1].set_title('Gaussian vs Uniform (both standardised)')
axes[1].legend()
plt.tight_layout()
plt.show()