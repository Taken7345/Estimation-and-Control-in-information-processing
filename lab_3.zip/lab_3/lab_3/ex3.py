import numpy as np

rng = np.random.default_rng(seed=42)
X = rng.uniform(0, 1, size=1000)


sample_mean = np.mean(X)

theoretical_mean = (0 + 1) / 2   # = 0.5

error = abs(sample_mean - theoretical_mean)
pct_error = (error / theoretical_mean) * 100

print(f"Sample mean:      {sample_mean:.6f}")
print(f"Theoretical mean: {theoretical_mean:.6f}")
print(f"Absolute error:   {error:.6f}")
print(f"% error:          {pct_error:.4f}%")