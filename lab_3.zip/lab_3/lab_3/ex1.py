import numpy as np
import matplotlib.pyplot as plt

rng = np.random.default_rng(seed=42)
data = rng.standard_normal(1000)

plt.figure(figsize=(10, 6))
plt.hist(data, bins=30, color='steelblue', edgecolor='white', alpha=0.85)
plt.title('Histogram of 1000 Random Numbers (Normal Distribution)')
plt.xlabel('Value')
plt.ylabel('Frequency')
plt.grid(axis='y', alpha=0.3)
plt.tight_layout()
plt.show()

print(f"Mean:   {data.mean():.4f}")
print(f"Std:    {data.std():.4f}")
print(f"Min:    {data.min():.4f}")
print(f"Max:    {data.max():.4f}")


#Computers can't truly be random — they are deterministic machines. What NumPy gives you is a pseudo-random number generator (PRNG), specifically the PCG64 algorithm (since NumPy 1.17). It starts from a seed and applies a mathematical formula to produce a sequence of numbers that looks random and passes statistical tests, but is fully reproducible if you know the seed. That's why np.random.default_rng(seed=42) always gives the same sequence — useful for reproducible experiments.
#What the histogram tells you about randomness:

#With a normal distribution, values cluster near 0 and taper off symmetrically — this bell shape emerges naturally from many real-world processes (measurement error, biological variation, etc.) due to the Central Limit Theorem.
#With a uniform distribution, every value in the range is equally likely, so the histogram should be roughly flat — any peaks are just sampling noise.
#With exponential, values pile up near zero and have a long right tail — common in modeling wait times or lifetimes.

#A key insight: even though individual values are unpredictable, with enough samples the shape becomes very predictable — which is the foundation of statistics and probability theory. True randomness (from quantum noise or thermal fluctuations) exists in hardware random number generators, but for most scientific computing the pseudo-random kind is indistinguishable in practice.