import numpy as np

rng = np.random.default_rng(seed=42)
X = rng.uniform(0, 1, size=1000)

sample_var  = np.var(X, ddof=0)   
sample_var_unbiased = np.var(X, ddof=1)
sample_std  = np.std(X, ddof=1)

theoretical_var = (1 - 0)**2 / 12   
theoretical_std = theoretical_var**0.5

print(f"Sample variance (ddof=0):  {sample_var:.6f}")
print(f"Sample variance (ddof=1):  {sample_var_unbiased:.6f}")
print(f"Theoretical variance:      {theoretical_var:.6f}  (= 1/12)")
print(f"Sample std dev:            {sample_std:.6f}")
print(f"Theoretical std dev:       {theoretical_std:.6f}  (= 1/√12)")