import matplotlib.pyplot as plt
import numpy as np

n_steps = 50


x = np.zeros(n_steps)
for t in range(n_steps - 1):
    x[t+1] = x[t] + 1


np.random.seed(42)
noise = np.random.normal(0, 2, n_steps)
y = x + noise


window_size = 5  
x_est = np.zeros(n_steps)

for t in range(n_steps):
    if t < window_size - 1:
        
        x_est[t] = np.mean(y[:t+1])
    else:
        x_est[t] = np.mean(y[t-window_size+1 : t+1])

plt.figure(figsize=(10, 6))

plt.plot(range(n_steps), x, color='blue', linestyle='--', label='True State x(t)', linewidth=2)

plt.scatter(range(n_steps), y, color='red', label='Noisy Observations y(t)', marker='x', alpha=0.6)

plt.plot(range(n_steps), x_est, color='green', marker='s', linestyle='-', label=f'Estimated State (MA, w={window_size})', markersize=4)


plt.xlabel('Time step (t)')
plt.ylabel('Value')
plt.title('True State vs. Observations vs. Estimated State')
plt.grid(True)
plt.legend()
plt.tight_layout()

plt.savefig('moving_average_plot.png')