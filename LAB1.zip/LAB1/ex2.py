import matplotlib.pyplot as plt
import numpy as np


n_steps = 50


x = np.zeros(n_steps)
for t in range(n_steps - 1):
    x[t+1] = x[t] + 1


np.random.seed(42) 
noise = np.random.normal(0, 2, n_steps)


y = x + noise

plt.figure(figsize=(8, 5))
plt.plot(range(n_steps), x, marker='o', linestyle='-', color='b', label='True State x(t)', markersize=4)
plt.scatter(range(n_steps), y, color='r', label='Noisy Observations y(t)', marker='x', zorder=5)

plt.xlabel('Time step (t)')
plt.ylabel('Value')
plt.title('True State vs. Noisy Observations')
plt.grid(True)
plt.legend()
plt.tight_layout()

plt.savefig('true_vs_noisy.png')