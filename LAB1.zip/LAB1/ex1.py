import matplotlib.pyplot as plt
import numpy as np

n_steps = 50

x = np.zeros(n_steps)
x[0] = 0 

for t in range(n_steps - 1):
    x[t+1] = x[t] + 1


plt.figure(figsize=(8, 5))
plt.plot(range(n_steps), x, marker='o', linestyle='-', color='b', label='True State', markersize=4)

plt.xlabel('Time step (t)')
plt.ylabel('State x(t)')
plt.title('Evolution of the True State: x(t+1) = x(t) + 1')
plt.grid(True)
plt.legend()
plt.tight_layout()

plt.savefig('true_state.png')