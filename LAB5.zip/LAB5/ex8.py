import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)
A, B, C = 1.0, 1.0, 1.0
T, u = 30, 1.0
sigma_w, sigma_v = 0.1, 0.5
Q, R = 0.01, 0.5


x_true = np.zeros(T + 1)
for t in range(T):
    x_true[t+1] = A*x_true[t] + B*u + np.random.normal(0, sigma_w)
y_meas = np.array([C*x_true[t] + np.random.normal(0, sigma_v) for t in range(T+1)])

x_hat   = np.zeros(T + 1)
P_post  = np.zeros(T + 1)   
P_prior = np.zeros(T + 1)   

x_hat[0], P_post[0] = 0.0, 1.0

for t in range(1, T + 1):
    xp = A*x_hat[t-1] + B*u
    Pp = A*P_post[t-1]*A + Q     
    P_prior[t] = Pp

    K = Pp*C / (C*Pp*C + R)
    x_hat[t]  = xp + K*(y_meas[t] - C*xp)
    P_post[t] = (1 - K*C)*Pp   

time = np.arange(1, T + 1)  
plt.figure(figsize=(10, 5))
plt.plot(time, P_prior[1:], linestyle='dotted', marker='o', label='P(t|t-1)  predicted')
plt.plot(time, P_post[1:],  linestyle='-',      marker='s', label='P(t|t)    updated')
plt.xlabel('Time step t')
plt.ylabel('Covariance')
plt.title('Exercise 8: Predicted vs Updated Covariance')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig('ex8_covariance.png')
plt.show()