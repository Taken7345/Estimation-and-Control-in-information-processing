import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

A, B, C = 1.0, 1.0, 1.0
T, u = 30, 1.0
sigma_w, sigma_v = 0.1, 0.5
Q, R = 0.01, 0.5

x_true = np.zeros(T + 1)
for t in range(T):
    x_true[t+1] = A*x_true[t] + B*u + np.random.normal(0, sigma_w)
y_meas = np.array([C*x_true[t] + np.random.normal(0, sigma_v) for t in range(T+1)])

x_pred = np.zeros(T + 1)
for t in range(T):
    x_pred[t+1] = A*x_pred[t] + B*u

x_hat, P = np.zeros(T + 1), np.zeros(T + 1)
x_hat[0], P[0] = 0.0, 1.0
for t in range(1, T + 1):
    xp = A*x_hat[t-1] + B*u
    Pp = A*P[t-1]*A + Q
    K  = Pp*C / (C*Pp*C + R)
    x_hat[t] = xp + K*(y_meas[t] - C*xp)
    P[t]     = (1 - K*C)*Pp

mse_pred = np.mean((x_true[1:] - x_pred[1:])**2)
mse_kf   = np.mean((x_true[1:] - x_hat[1:])**2)
print(f"MSE Prediction only: {mse_pred:.4f}")
print(f"MSE Kalman filter  : {mse_kf:.4f}")

time = np.arange(T + 1)
plt.figure(figsize=(10, 5))
plt.plot(time, x_true, label='True state x(t)',         marker='o')
plt.plot(time, x_pred, label=f'Prediction only (MSE={mse_pred:.3f})', linestyle='dotted',  marker='s')
plt.plot(time, x_hat,  label=f'Kalman filter (MSE={mse_kf:.3f})',     linestyle='dashed',  marker='^')
plt.xlabel('Time step t')
plt.ylabel('Value')
plt.title('Exercise 5: Prediction-Only vs Full Kalman Filter')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig('ex5_comparison.png')
plt.show()
