import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)


A, B, C = 1.0, 1.0, 1.0
T = 30
u = 1.0
sigma_w, sigma_v = 0.1, 0.5
Q = 0.01   
R = 0.5   

x_true = np.zeros(T + 1)
for t in range(T):
    x_true[t + 1] = A * x_true[t] + B * u + np.random.normal(0, sigma_w)

y_meas = np.array([C * x_true[t] + np.random.normal(0, sigma_v) for t in range(T + 1)])

x_hat = np.zeros(T + 1)   
P     = np.zeros(T + 1)  
K_arr = np.zeros(T + 1)

x_hat[0] = 0.0
P[0]      = 1.0            

for t in range(1, T + 1):
    x_pred = A * x_hat[t-1] + B * u
    P_pred = A * P[t-1] * A + Q

    K = P_pred * C / (C * P_pred * C + R)
    x_hat[t] = x_pred + K * (y_meas[t] - C * x_pred)
    P[t]      = (1 - K * C) * P_pred
    K_arr[t]  = K

time = np.arange(T + 1)

fig, axes = plt.subplots(2, 1, figsize=(10, 8))

axes[0].plot(time, x_true,  label='True state x(t)',     marker='o')
axes[0].plot(time, y_meas,  label='Noisy meas y(t)',     marker='x', linestyle='none')
axes[0].plot(time, x_hat,   label='Kalman estimate',     marker='s', linestyle='--')
axes[0].set_xlabel('Time t')
axes[0].set_ylabel('Value')
axes[0].set_title('Kalman Filter: State Estimation')
axes[0].legend()
axes[0].grid(True)

axes[1].plot(time, K_arr, label='Kalman gain K(t)',     marker='o')
axes[1].plot(time, P,     label='Covariance P(t|t)',    marker='s', linestyle='--')
axes[1].set_xlabel('Time t')
axes[1].set_ylabel('Value')
axes[1].set_title('Kalman Gain and Error Covariance')
axes[1].legend()
axes[1].grid(True)

plt.tight_layout()
plt.savefig('kalman_filter.png')
plt.show()