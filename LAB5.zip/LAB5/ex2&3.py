import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

A, B, C = 1, 1, 1
T = 30
u = 1
sigma_w = 0.1
sigma_v = 0.5


x = np.zeros(T + 1)
for t in range(T):
    w = np.random.normal(0, sigma_w)
    x[t + 1] = A * x[t] + B * u + w

x_pred = np.zeros(T + 1)
x_pred[0] = 0

for t in range(T):
    x_pred[t + 1] = A * x_pred[t] + B * u


time = np.arange(T + 1)
plt.figure(figsize=(10, 5))
plt.plot(time, x,      label='True state x(t)',       marker='o')
plt.plot(time, x_pred, label='Predicted x̂(t|t-1)',   marker='s', linestyle='--')
plt.xlabel('Time step t')
plt.ylabel('Value')
plt.title('Exercise 2: True State vs Open-Loop Prediction')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig('prediction_step.png')
plt.show()