import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)


A, B, C = 1, 1, 1
T = 30
u = 1  

sigma_w = 0.1  
sigma_v = 0.5  

x = np.zeros(T + 1)
for t in range(T):
    w = np.random.normal(0, sigma_w)
    x[t + 1] = A * x[t] + B * u + w

y = np.zeros(T + 1)
for t in range(T + 1):
    v = np.random.normal(0, sigma_v)
    y[t] = C * x[t] + v

time = np.arange(T + 1)
plt.figure(figsize=(10, 5))
plt.plot(time, x, label='True state x(t)', marker='o')
plt.plot(time, y, label='Noisy measurement y(t)', marker='x', linestyle='--')
plt.xlabel('Time step t')
plt.ylabel('Value')
plt.title('Linear Dynamical System: True State vs Noisy Measurement')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig('linear_system.png')
plt.show()