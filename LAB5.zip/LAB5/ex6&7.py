import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)
A, B, C = 1.0, 1.0, 1.0
T, u = 30, 1.0
sigma_w, sigma_v = 0.1, 0.5

x_true = np.zeros(T + 1)
for t in range(T):
    x_true[t+1] = A*x_true[t] + B*u + np.random.normal(0, sigma_w)
y_meas = np.array([C*x_true[t] + np.random.normal(0, sigma_v) for t in range(T+1)])

def run_kalman(Q, R):
    x_hat, P = np.zeros(T+1), np.zeros(T+1)
    x_hat[0], P[0] = 0.0, 1.0
    for t in range(1, T+1):
        xp = A*x_hat[t-1] + B*u
        Pp = A*P[t-1]*A + Q
        K  = Pp*C / (C*Pp*C + R)
        x_hat[t] = xp + K*(y_meas[t] - C*xp)
        P[t]     = (1 - K*C)*Pp
    return x_hat, np.mean((x_true[1:] - x_hat[1:])**2)

time = np.arange(T+1)

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
axes[0].plot(time, x_true, 'k-', linewidth=2, label='True state')
for Q in [0.0001, 0.01, 1]:
    xh, mse = run_kalman(Q, R=0.5)
    axes[0].plot(time, xh, marker='o', markersize=3, label=f'Q={Q} (MSE={mse:.3f})')
axes[0].set_title('Effect of Q (R=0.5 fixed)')
axes[0].set_xlabel('Time t'); axes[0].set_ylabel('Value')
axes[0].legend(); axes[0].grid(True)

axes[1].plot(time, x_true, 'k-', linewidth=2, label='True state')
for R in [0.01, 0.5, 5]:
    xh, mse = run_kalman(Q=0.01, R=R)
    axes[1].plot(time, xh, marker='o', markersize=3, label=f'R={R} (MSE={mse:.3f})')
axes[1].set_title('Effect of R (Q=0.01 fixed)')
axes[1].set_xlabel('Time t'); axes[1].set_ylabel('Value')
axes[1].legend(); axes[1].grid(True)

plt.tight_layout()
plt.savefig('ex6_ex7.png')
plt.show()