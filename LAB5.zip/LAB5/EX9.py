import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

dt = 1.0
A = np.array([[1, dt], [0, 1]])
C = np.array([[1, 0]])
T = 30
v0 = 2.0  # constant velocity

Q = np.array([[0.01, 0], [0, 0.01]])  # process noise covariance
R = np.array([[1.0]])                  # measurement noise covariance

# True state: [position, velocity]
x_true = np.zeros((2, T + 1))
x_true[:, 0] = [0.0, v0]
for t in range(T):
    w = np.random.multivariate_normal([0, 0], Q)
    x_true[:, t+1] = A @ x_true[:, t] + w

# Noisy measurements (position only)
y_meas = np.array([C @ x_true[:, t] + np.random.normal(0, np.sqrt(R[0,0]))
                   for t in range(T+1)]).flatten()

# Kalman Filter
x_hat = np.zeros((2, T + 1))
x_hat[:, 0] = [0.0, 0.0]   # initial estimate: position=0, velocity unknown
P = np.eye(2)               # initial covariance P(0|0)

for t in range(1, T + 1):
    # Prediction
    xp = A @ x_hat[:, t-1]
    Pp = A @ P @ A.T + Q

    # Update
    S  = C @ Pp @ C.T + R
    K  = Pp @ C.T @ np.linalg.inv(S)
    x_hat[:, t] = xp + K.flatten() * (y_meas[t] - C @ xp)
    P = (np.eye(2) - K @ C) @ Pp

time = np.arange(T + 1)

# Plot
fig, axes = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

axes[0].plot(time, x_true[0], label='True position',  color='blue')
axes[0].plot(time, y_meas,    label='Noisy meas',      linestyle='none', marker='x', color='gray')
axes[0].plot(time, x_hat[0],  label='KF position',     linestyle='--', color='red')
axes[0].set_ylabel('Position'); axes[0].legend(); axes[0].grid(True)

axes[1].plot(time, x_true[1], label='True velocity',   color='green')
axes[1].plot(time, x_hat[1],  label='KF velocity',     linestyle='--', color='orange')
axes[1].set_ylabel('Velocity'); axes[1].set_xlabel('Time t')
axes[1].legend(); axes[1].grid(True)

plt.suptitle('Exercise 9: 2D Kalman Filter — Position & Velocity')
plt.tight_layout()
plt.savefig('ex9_kalman_2d.png')
plt.show()