import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

A, B, C = 1.0, 1.0, 1.0
T, L = 30, 0.5
Q_kf, R_kf = 0.01, 0.5
sigma_w, sigma_v = 0.1, 0.5

x_true = np.zeros(T + 1)
x_hat  = np.zeros(T + 1)
P      = np.zeros(T + 1)
u_arr  = np.zeros(T + 1)

x_true[0] = 5.0   # start away from 0 so control effect is visible
x_hat[0]  = 0.0
P[0]      = 1.0

for t in range(T):
    # Control law using Kalman estimate
    u = -L * x_hat[t]
    u_arr[t] = u

    # True system evolves with control + noise
    x_true[t+1] = A * x_true[t] + B * u + np.random.normal(0, sigma_w)

    # Noisy measurement
    y = C * x_true[t+1] + np.random.normal(0, sigma_v)

    # Kalman predict & update
    xp = A * x_hat[t] + B * u
    Pp = A * P[t] * A + Q_kf
    K  = Pp * C / (C * Pp * C + R_kf)
    x_hat[t+1] = xp + K * (y - C * xp)
    P[t+1]     = (1 - K * C) * Pp

u_arr[T] = -L * x_hat[T]

time = np.arange(T + 1)

fig, axes = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

axes[0].plot(time, x_true, label='True state x(t)',     color='blue',  marker='o')
axes[0].plot(time, x_hat,  label='KF estimate x̂(t|t)', color='red',   linestyle='--', marker='s')
axes[0].axhline(0, color='gray', linestyle=':')
axes[0].set_ylabel('State'); axes[0].legend(); axes[0].grid(True)
axes[0].set_title('State: True vs Estimated')

axes[1].plot(time, u_arr, label='Control u(t) = -Lx̂', color='green', marker='o')
axes[1].axhline(0, color='gray', linestyle=':')
axes[1].set_ylabel('Control'); axes[1].set_xlabel('Time t')
axes[1].legend(); axes[1].grid(True)
axes[1].set_title('Control Signal')

plt.suptitle('Exercise 10: Closed-Loop State Feedback (L=0.5)')
plt.tight_layout()
plt.savefig('ex10_feedback.png')
plt.show()