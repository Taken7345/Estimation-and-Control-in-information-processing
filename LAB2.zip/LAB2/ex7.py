import matplotlib.pyplot as plt

# 1. Define the predetermined sequence S and updated weights
S = ['A', 'C', 'C', 'B', 'B', 'A', 'B', 'A', 'C', 'C', 'C', 'A', 'B', 'B', 'A']
weights = {'A': 1.5, 'B': 0.5, 'C': 3.3}

# 2. Starting population
P = [0.5]

# 3. Calculate population for each step in sequence S
for state in S:
    r = weights[state]
    p_next = r * P[-1] * (1 - P[-1])
    
    # Cap negative numbers at 0 (extinction) just in case
    if p_next < 0:
        p_next = 0
        
    P.append(p_next)

# 4. Create the plot
plt.figure(figsize=(10, 5))
plt.plot(range(16), P, marker='o', linestyle='-', color='purple', linewidth=2)
plt.title("Population Evolution (Modified weight B = 0.5)")
plt.xlabel("Step")
plt.ylabel("Population Size")
plt.xticks(range(16))
plt.grid(True, linestyle='--')
plt.tight_layout()

# Save and show the plot
plt.show()

print(f"Final population after 15 steps: {P[-1]:.4f}")