ARHIR TUDOR-CRISTIAN

1. Make a simulation by using the logistic regression(population growth) expression 
use a growth factor r equal to 0.9 . make a raport (word doc) that describes the fate of the population 
for r=0.9
 
2.Use your simulation to point out at what value of r, the population growth becomes chaotic.
Show your result with a screenshot (plot the data).

3.For each value of r, calculate the population size and plot the data: r=[2, 2.5, 1, 1.2, 3.1, 0.5, 4, 4.4,
3, 2.9, 2.8, 1.9, 1.5, 1.4, 7, 3.8, 8]

4. Consider the above vector as values for r factor, measured here, across 17 years. Answer; "What will 
be the population growth in 17th year?"

5. Make a series of experiments in which the population number starts from :
a) 0.1
b) 0.5
c) 1.0
d) 2
Make the report in which you note the observations for r=4.

6.  Simulate a Markov machine containing 3 states A,B,C :in the image; Run this machine 15 times and record the sequence of states. Store these states as "S": Each state carries a weight: 

A:1.5

B:2

C:3.3

Use these weights as values for the growth factor r, and calculate the population size on 15 steps

according to the weights form S. Start the population from 0.5

7. Modify the value of the weight of state B to a value of 0.5. Plot the evolution of the population for 15 steps based on sequence S. Answer the question: "Does the population survive after 15 steps?".