import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt


def logistic_growth(P, t, r, K):
    """
    Calculates the rate of change of the population.
    """
    dPdt = r * P * (1 - P / K)
    return dPdt


r = 0.9      
K = 1000      
P0 = 10      
t = np.linspace(0, 15, 100)  

population = odeint(logistic_growth, P0, t, args=(r, K))

# 4. Plot the results
plt.figure(figsize=(10, 6))
plt.plot(t, population, 'b-', linewidth=2, label=f'Growth Rate (r) = {r}')
plt.axhline(y=K, color='r', linestyle='--', label=f'Carrying Capacity (K) = {K}')

# Formatting the plot
plt.title('Logistic Population Growth Simulation')
plt.xlabel('Time')
plt.ylabel('Population Size')
plt.legend(loc='best')
plt.grid(True)
plt.tight_layout()

plt.show()
