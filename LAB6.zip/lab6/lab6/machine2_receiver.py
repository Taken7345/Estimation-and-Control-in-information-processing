"""
MACHINE 2 — RECEIVER  +  SIGNAL PROCESSING
============================================
Run this on the second PC/laptop (2 metres away from Machine 1).
It records whatever the microphone captures, then applies:

  1. Amplification          – boosts the signal gain
  2. Noise Gate             – silences frames below a noise floor
  3. FIR Band-pass filter   – keeps only voice frequencies (80 Hz – 8 kHz)
                              implemented FROM SCRATCH with the Windowed-Sinc method
  4. Normalisation          – brings the final output to a safe peak level

ALL signal processing uses only NumPy arrays — no scipy.signal, no librosa.

# %%


Install:  pip install sounddevice numpy
Usage:    python machine2_receiver.py
"""

import sounddevice as sd
import numpy as np
import wave
import struct
import time

# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
SAMPLE_RATE        = 44100   # Hz  — must match Machine 1
CHANNELS           = 1
RECORD_SECONDS     = 8       # record a bit longer than Machine 1's clip
AMPLIFICATION_DB   = 12.0    # dB to add  (6 dB ≈ ×2 in amplitude)
NOISE_GATE_THRESH  = 0.01    # frames with RMS below this → zeroed out
GATE_FRAME_SIZE    = 512     # samples per gate frame
VOICE_LOW_HZ       = 80      # lower cut-off  (remove rumble / AC hum)
VOICE_HIGH_HZ      = 8000    # upper cut-off  (remove high-freq hiss)
FIR_NUM_TAPS       = 301     # filter length  (odd number, higher = sharper)
RAW_FILE           = "received_raw.wav"
PROCESSED_FILE     = "received_processed.wav"


# ══════════════════════════════════════════════
#  WAV I/O  (stdlib only — no scipy)
# ══════════════════════════════════════════════

def save_wav(filename, data, sample_rate, channels=1, sample_width=2):
    """Save float32 numpy array → 16-bit WAV."""
    data_clipped = np.clip(data, -1.0, 1.0)
    data_int16   = (data_clipped * 32767).astype(np.int16)
    with wave.open(filename, 'w') as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sample_width)
        wf.setframerate(sample_rate)
        raw = struct.pack(f"<{len(data_int16)}h", *data_int16)
        wf.writeframes(raw)


# ══════════════════════════════════════════════
#  DSP FUNCTIONS — all implemented from scratch
# ══════════════════════════════════════════════

# ──────────────────────────────────────────────
#  1. AMPLIFICATION
#    Converts dB gain to a linear multiplier and applies it.
#    Formula:  amplitude_factor = 10^(dB / 20)
# ──────────────────────────────────────────────
def amplify(signal: np.ndarray, gain_db: float) -> np.ndarray:
    """
    Amplify (or attenuate) a signal by gain_db decibels.
    gain_db > 0  →  louder
    gain_db < 0  →  quieter
    """
    linear_gain = 10.0 ** (gain_db / 20.0)
    amplified   = signal * linear_gain
    print(f"   [Amplify]  +{gain_db} dB  →  linear factor {linear_gain:.3f}")
    return amplified


# ──────────────────────────────────────────────
#  2. NOISE GATE
#    Splits signal into short frames; any frame whose RMS energy
#    is below the threshold is set to zero (silenced).
# ──────────────────────────────────────────────
def noise_gate(signal: np.ndarray,
               threshold: float,
               frame_size: int) -> np.ndarray:
    """
    Zero out frames that are quieter than `threshold` RMS.
    Works entirely with numpy array slicing — no external DSP library.
    """
    output       = signal.copy()
    n_frames     = len(signal) // frame_size
    gated_frames = 0

    for i in range(n_frames):
        start = i * frame_size
        end   = start + frame_size
        frame = signal[start:end]
        rms   = np.sqrt(np.mean(frame ** 2))
        if rms < threshold:
            output[start:end] = 0.0
            gated_frames += 1

    # Handle leftover samples
    remainder_start = n_frames * frame_size
    if remainder_start < len(signal):
        frame = signal[remainder_start:]
        rms   = np.sqrt(np.mean(frame ** 2))
        if rms < threshold:
            output[remainder_start:] = 0.0
            gated_frames += 1

    pct = 100.0 * gated_frames / max(n_frames, 1)
    print(f"   [Noise Gate]  threshold={threshold:.4f}  "
          f"→  {gated_frames}/{n_frames} frames silenced ({pct:.1f}%)")
    return output


# ──────────────────────────────────────────────
#  3. FIR BAND-PASS FILTER  (Windowed-Sinc method)
#
#  Theory:
#    A band-pass filter passes frequencies between f_low and f_high
#    and attenuates everything else.
#
#    Construction (from scratch):
#      a) Build a LOW-pass sinc kernel at f_high
#      b) Build a LOW-pass sinc kernel at f_low
#      c) Subtract (b) from (a) to get a BAND-pass kernel
#      d) Multiply by a Hann window to reduce side-lobes
#      e) Apply the filter via direct convolution (np.convolve)
#
#    sinc(x) = sin(π x) / (π x)
#    Normalised cut-off:  f_c = frequency / sample_rate
# ──────────────────────────────────────────────
def _sinc_lowpass_kernel(cutoff_hz: float,
                         sample_rate: int,
                         num_taps: int) -> np.ndarray:
    """
    Windowed-sinc low-pass FIR kernel.
    cutoff_hz  : -3 dB frequency in Hz
    num_taps   : filter length (odd integer for symmetry)
    """
    if num_taps % 2 == 0:
        num_taps += 1   # force odd

    fc    = cutoff_hz / sample_rate          # normalised [0, 0.5]
    M     = num_taps - 1                     # filter order
    n     = np.arange(num_taps) - M / 2.0   # symmetric around 0

    # Sinc kernel (handle n=0 with a limit of 2*fc)
    with np.errstate(divide='ignore', invalid='ignore'):
        h = np.where(n == 0.0,
                     2.0 * fc,
                     np.sin(2.0 * np.pi * fc * n) / (np.pi * n))

    # Hann window  (reduces spectral leakage)
    window = 0.5 - 0.5 * np.cos(2.0 * np.pi * np.arange(num_taps) / M)
    h *= window

    # Normalise so DC gain = 1
    h /= np.sum(h)
    return h


def fir_bandpass(signal: np.ndarray,
                 low_hz: float,
                 high_hz: float,
                 sample_rate: int,
                 num_taps: int) -> np.ndarray:
    """
    Band-pass FIR filter built entirely from scratch.
    Passes frequencies between low_hz and high_hz.
    Uses numpy's 1-D discrete convolution (np.convolve).
    """
    # Build low-pass kernels
    h_high = _sinc_lowpass_kernel(high_hz, sample_rate, num_taps)
    h_low  = _sinc_lowpass_kernel(low_hz,  sample_rate, num_taps)

    # Band-pass = low-pass(high) − low-pass(low)
    h_bp   = h_high - h_low

    # Convolve signal with the band-pass kernel
    # 'same' mode: output length equals input length
    filtered = np.convolve(signal, h_bp, mode='same')

    print(f"   [FIR Band-pass]  {low_hz} Hz – {high_hz} Hz  "
          f"| taps={num_taps}  | kernel peak={np.max(np.abs(h_bp)):.6f}")
    return filtered.astype(np.float32)


# ──────────────────────────────────────────────
#  4. PEAK NORMALISATION
#    Rescales so the loudest sample = target_peak (avoids clipping).
# ──────────────────────────────────────────────
def peak_normalise(signal: np.ndarray, target_peak: float = 0.9) -> np.ndarray:
    """Scale signal so its absolute peak equals target_peak."""
    peak = np.max(np.abs(signal))
    if peak < 1e-9:
        print("   [Normalise]  signal is (nearly) silent — skipped")
        return signal
    normalised = signal * (target_peak / peak)
    print(f"   [Normalise]  peak {peak:.4f} → {target_peak:.4f}  "
          f"(×{target_peak / peak:.3f})")
    return normalised


# ──────────────────────────────────────────────
#  SIGNAL STATS  (helper for before/after comparison)
# ──────────────────────────────────────────────
def print_stats(label: str, signal: np.ndarray):
    rms  = np.sqrt(np.mean(signal ** 2))
    peak = np.max(np.abs(signal))
    rms_db  = 20.0 * np.log10(rms  + 1e-9)
    peak_db = 20.0 * np.log10(peak + 1e-9)
    print(f"   [{label}]  RMS={rms:.5f} ({rms_db:.1f} dBFS)  "
          f"Peak={peak:.5f} ({peak_db:.1f} dBFS)")


# ══════════════════════════════════════════════
#  MAIN PIPELINE
# ══════════════════════════════════════════════

def record_audio() -> np.ndarray:
    print(f"\n▶  Recording {RECORD_SECONDS}s from microphone …")
    print("   (Make sure Machine 1 is playing!)\n")
    audio = sd.rec(
        int(RECORD_SECONDS * SAMPLE_RATE),
        samplerate=SAMPLE_RATE,
        channels=CHANNELS,
        dtype='float32'
    )
    sd.wait()
    audio = audio.flatten()
    print(f"   ✓ Captured {len(audio)} samples")
    return audio


def process(raw: np.ndarray) -> np.ndarray:
    print("\n── Processing pipeline ─────────────────")

    print_stats("RAW input", raw)
    save_wav(RAW_FILE, raw, SAMPLE_RATE)
    print(f"   ✓ Raw saved → '{RAW_FILE}'")

    # Step 1 — Amplify
    sig = amplify(raw, AMPLIFICATION_DB)

    # Step 2 — Noise Gate
    sig = noise_gate(sig, NOISE_GATE_THRESH, GATE_FRAME_SIZE)

    # Step 3 — Band-pass filter  (voice frequencies)
    sig = fir_bandpass(sig, VOICE_LOW_HZ, VOICE_HIGH_HZ,
                       SAMPLE_RATE, FIR_NUM_TAPS)

    # Step 4 — Normalise
    sig = peak_normalise(sig, target_peak=0.9)

    print_stats("PROCESSED output", sig)
    save_wav(PROCESSED_FILE, sig, SAMPLE_RATE)
    print(f"   ✓ Processed saved → '{PROCESSED_FILE}'")
    print("────────────────────────────────────────")
    return sig


def play_result(signal: np.ndarray):
    answer = input("\n▶  Play processed audio through speakers? [y/n]: ").strip().lower()
    if answer == 'y':
        print("   Playing …")
        sd.play(signal, samplerate=SAMPLE_RATE)
        sd.wait()
        print("   ✓ Done.")


def main():
    print("\n╔══════════════════════════════════════╗")
    print("║     MACHINE 2  —  RECEIVER / DSP     ║")
    print("╚══════════════════════════════════════╝")
    input("\n   Press ENTER when ready to record …")

    raw       = record_audio()
    processed = process(raw)
    play_result(processed)

    print(f"\n✅  Files written:")
    print(f"     • {RAW_FILE}        ← original capture")
    print(f"     • {PROCESSED_FILE}  ← amplified + filtered\n")


if __name__ == "__main__":
    main()
