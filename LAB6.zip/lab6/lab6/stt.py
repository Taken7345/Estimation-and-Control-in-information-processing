"""
stt_engine.py  —  Speech-to-Text using Vosk  (offline, no API key)
===================================================================
Vosk is the minimal viable choice when:
  • no internet connection during experiment
  • teacher forbids cloud APIs (Google, Azure, AWS)
  • need reproducible offline results

The acoustic model (≈50 MB) is downloaded ONCE automatically.
After that everything runs fully offline.

Install:
    pip install vosk sounddevice numpy

Model download (automatic on first run):
    https://alphacephei.com/vosk/models  →  vosk-model-small-en-us-0.15
"""

import os
import json
import wave
import struct
import urllib.request
import zipfile
import numpy as np

# ── Lazy import: only needed at transcription time ───────────────
try:
    from vosk import Model, KaldiRecognizer
    VOSK_AVAILABLE = True
except ImportError:
    VOSK_AVAILABLE = False

MODEL_DIR  = "vosk_model"
MODEL_URL  = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
MODEL_ZIP  = "vosk-model-small-en-us-0.15.zip"
MODEL_NAME = "vosk-model-small-en-us-0.15"   # folder inside the zip


# ─────────────────────────────────────────────────────────────
#  MODEL DOWNLOAD (stdlib only — urllib, zipfile)
# ─────────────────────────────────────────────────────────────

def _download_model():
    """Download and unzip the Vosk small English model (≈50 MB)."""
    if os.path.isdir(MODEL_DIR):
        return   # already downloaded

    print(f"\n[STT] Model not found. Downloading {MODEL_NAME} (~50 MB) …")
    print(f"      Source: {MODEL_URL}\n")

    # Download with progress
    def _reporthook(count, block_size, total_size):
        pct = min(100, int(count * block_size * 100 / max(total_size, 1)))
        bar = '█' * (pct // 5) + '░' * (20 - pct // 5)
        print(f"\r      [{bar}] {pct}%", end='', flush=True)

    urllib.request.urlretrieve(MODEL_URL, MODEL_ZIP, reporthook=_reporthook)
    print()

    print("[STT] Extracting …")
    with zipfile.ZipFile(MODEL_ZIP, 'r') as zf:
        zf.extractall('.')
    os.rename(MODEL_NAME, MODEL_DIR)
    os.remove(MODEL_ZIP)
    print(f"[STT] Model ready at './{MODEL_DIR}'\n")


# ─────────────────────────────────────────────────────────────
#  CORE TRANSCRIPTION
# ─────────────────────────────────────────────────────────────

def transcribe_wav(wav_path: str,
                   chunk_size: int = 4000) -> str:
    """
    Transcribe a WAV file to text using Vosk offline ASR.

    Parameters
    ----------
    wav_path   : path to a .wav file (any sample rate — resampled if needed)
    chunk_size : audio chunk size fed to the recogniser at a time

    Returns
    -------
    Transcribed string (may be empty if audio is silent/unrecognisable)
    """
    if not VOSK_AVAILABLE:
        raise RuntimeError(
            "Vosk is not installed. Run:  pip install vosk"
        )

    _download_model()

    model = Model(MODEL_DIR)

    with wave.open(wav_path, 'r') as wf:
        sr       = wf.getframerate()
        n_ch     = wf.getnchannels()
        n_frames = wf.getnframes()
        raw_data = wf.readframes(n_frames)

    # Convert to mono int16 numpy array
    audio_int16 = np.frombuffer(raw_data, dtype=np.int16)
    if n_ch > 1:
        audio_int16 = audio_int16[::n_ch]   # keep channel 0

    # Resample to 16 000 Hz (Vosk's native rate) if needed
    if sr != 16000:
        audio_int16 = _resample(audio_int16, sr, 16000)
        sr = 16000

    rec = KaldiRecognizer(model, sr)
    rec.SetWords(True)

    # Feed audio in chunks
    results = []
    audio_bytes = audio_int16.astype(np.int16).tobytes()
    for start in range(0, len(audio_bytes), chunk_size * 2):
        chunk = audio_bytes[start : start + chunk_size * 2]
        if rec.AcceptWaveform(chunk):
            part = json.loads(rec.Result())
            if part.get('text'):
                results.append(part['text'])

    # Final partial result
    final = json.loads(rec.FinalResult())
    if final.get('text'):
        results.append(final['text'])

    return ' '.join(results).strip()


# ─────────────────────────────────────────────────────────────
#  RESAMPLING  (pure numpy — no scipy)
#
#  Simple linear interpolation resampler.
#  Good enough for speech (not for music at high quality).
# ─────────────────────────────────────────────────────────────

def _resample(audio: np.ndarray,
              orig_sr: int,
              target_sr: int) -> np.ndarray:
    """
    Resample a mono int16 audio array from orig_sr to target_sr
    using linear interpolation — no scipy, no resampy.
    """
    if orig_sr == target_sr:
        return audio

    orig_len   = len(audio)
    target_len = int(orig_len * target_sr / orig_sr)

    # Build the output sample positions in the original index space
    orig_indices = np.linspace(0, orig_len - 1, target_len)

    # Integer and fractional parts
    idx_low  = np.floor(orig_indices).astype(np.int64)
    idx_high = np.minimum(idx_low + 1, orig_len - 1)
    frac     = orig_indices - idx_low

    # Linear interpolation
    audio_f = audio.astype(np.float32)
    resampled = audio_f[idx_low] + frac * (audio_f[idx_high] - audio_f[idx_low])

    return np.round(resampled).astype(np.int16)


# ─────────────────────────────────────────────────────────────
#  CONVENIENCE: transcribe numpy float32 array directly
# ─────────────────────────────────────────────────────────────

def transcribe_array(audio: np.ndarray,
                     sample_rate: int,
                     tmp_path: str = "_tmp_transcribe.wav") -> str:
    """
    Transcribe a float32 numpy audio array directly (no temp file on disk).
    Writes a temporary WAV, transcribes, then deletes it.
    """
    # Save to temp WAV
    data_int16 = np.clip(audio, -1.0, 1.0)
    data_int16 = (data_int16 * 32767).astype(np.int16)
    with wave.open(tmp_path, 'w') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(struct.pack(f"<{len(data_int16)}h", *data_int16))

    text = transcribe_wav(tmp_path)

    if os.path.exists(tmp_path):
        os.remove(tmp_path)

    return text


# ─────────────────────────────────────────────────────────────
#  CLI  usage
# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python stt_engine.py <audio.wav>")
        sys.exit(1)

    wav_file = sys.argv[1]
    print(f"\n[STT] Transcribing: {wav_file}")
    text = transcribe_wav(wav_file)
    print(f"\n▶ Transcript:\n  \"{text}\"\n")